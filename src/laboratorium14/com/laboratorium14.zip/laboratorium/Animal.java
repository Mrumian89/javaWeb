package laboratorium14.com.laboratorium;

public abstract class Animal {

    public abstract String getType();

    public abstract int getInstanceNumber();

}

