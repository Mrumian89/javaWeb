package laboratorium14.com.laboratorium;

public class Kot extends Animal {

    @Override
    public String getType() {
        return "Kot";
    }

    @Override
    public int getInstanceNumber() {
        return 0;
    }
}

