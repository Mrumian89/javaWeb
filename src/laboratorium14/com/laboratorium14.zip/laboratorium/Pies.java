package laboratorium14.com.laboratorium;

public class Pies extends Animal {

    @Override
    public String getType() {
        return "Pies";
    }

    @Override
    public int getInstanceNumber() {
        return 0;
    }
}