package laboratorium14.com.laboratorium;

public class Ptak extends Animal {

    @Override
    public String getType() {
        return "Ptak";
    }

    @Override
    public int getInstanceNumber() {
        return 0;
    }
}
