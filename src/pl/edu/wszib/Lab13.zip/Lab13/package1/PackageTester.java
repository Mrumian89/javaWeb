package pl.edu.wszib.Lab13.package1;

public class PackageTester {
    public void show() {
    System.out.println("Pakiet "+ this.getClass().getPackage());
    }
}