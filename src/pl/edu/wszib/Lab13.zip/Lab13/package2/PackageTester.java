package pl.edu.wszib.Lab13.package2;

public class PackageTester {
    public void show() {
        System.out.println("Pakiet " + this.getClass().getPackage());
    }
}
